
#########################################################################################################
#######PRETRAITEMENT 1 AN
#########################################################################################################

#Import des fichiers

# 1) Fichier des poids (de chaque modèle au sein d'une classe d'ancienneté)
poids_1=read.csv2("Poids_1an.csv",sep=";")

# 2) Fichiers des glissements annuels
glissements_1_brouillon=read.csv2("Glissements_1.csv",sep=";")
#Pour se débarrasser de ces histoires de factors...
glissements_1<-as.matrix(glissements_1_brouillon)
glissements_1<-apply(as.matrix(glissements_1),FUN=as.numeric,1)
glissements_1<-apply(glissements_1,FUN=identity,1)
glissements_1[which(is.na(glissements_1))]<-1 #S'il y a une valeur manquante, on la neutralise
glissements_1[which(glissements_1==0)]<-1
glissements_1<-data.frame(glissements_1)
names(glissements_1)<- names(glissements_1_brouillon)
l=length(glissements_1[1,])
#On visualise les glissements annuels moyens
glissements_1_moyens<-0*glissements_1[1,]
for (j in c(1:l)){
  glissements_1_moyens[j]<-prod(glissements_1[1,j]^poids_1[,max(1,j-24)])^(1/12)
}
plot(c(1:l),glissements_1_moyens)


# 3) Fichier des indices publiés
indice_publie<-read.csv2("ind_publie.csv",sep=";")
indice_publie_9812<-indice_publie[1:180]
indice_publie_9813<-indice_publie[1:192]
plot(c(1:length(indice_publie_9812)),indice_publie_9812)




#########################################################################################################
#######PRETRAITEMENT 3 ANS
#########################################################################################################

#Import des fichiers

# 1) Fichier des poids (de chaque modèle au sein d'une classe d'ancienneté)
poids_3_brouillon=read.csv2("Poids_3an.csv",sep=";")
poids_3<-as.matrix(poids_3_brouillon)
poids_3<-apply(as.matrix(poids_3),FUN=as.numeric,1)
poids_3<-apply(poids_3,FUN=identity,1)
poids_3<-data.frame(poids_3)
names(poids_3)=names(poids_3_brouillon)
remove(poids_3_brouillon)

# 2) Fichiers des glissements annuels
glissements_3_brouillon=read.csv2("Glissements_3.csv",sep=";")
#Pour se débarrasser de ces histoires de factors...
glissements_3<-as.matrix(glissements_3_brouillon)
glissements_3<-apply(as.matrix(glissements_3),FUN=as.numeric,1)
glissements_3<-apply(glissements_3,FUN=identity,1)
glissements_3[which(is.na(glissements_3))]<-1 #S'il y a une valeur manquante, on la neutralise
glissements_3[which(glissements_3==0)]<-1
glissements_3<-data.frame(glissements_3)
names(glissements_3)<- names(glissements_3_brouillon)
l=length(glissements_3[1,])
remove(glissements_3_brouillon)


#########################################################################################################
#######PRETRAITEMENT 5 ANS
#########################################################################################################

#Import des fichiers

# 1) Fichier des poids (de chaque modèle au sein d'une classe d'ancienneté)
poids_5_brouillon=read.csv2("Poids_5an.csv",sep=";")
poids_5<-as.matrix(poids_5_brouillon)
poids_5<-apply(as.matrix(poids_5),FUN=as.numeric,1)
poids_5<-apply(poids_5,FUN=identity,1)
poids_5<-data.frame(poids_5)
names(poids_5)=names(poids_5_brouillon)
remove(poids_5_brouillon)

# 2) Fichiers des glissements annuels
glissements_5_brouillon=read.csv2("Glissements_5.csv",sep=";")
#Pour se débarrasser de ces histoires de factors...
glissements_5<-as.matrix(glissements_5_brouillon)
glissements_5<-apply(as.matrix(glissements_5),FUN=as.numeric,1)
glissements_5<-apply(glissements_5,FUN=identity,1)
glissements_5[which(is.na(glissements_5))]<-1 #S'il y a une valeur manquante, on la neutralise
glissements_5[which(glissements_5==0)]<-1
glissements_5<-data.frame(glissements_5)
names(glissements_5)<- names(glissements_5_brouillon)
l=length(glissements_5[1,])
remove(glissements_1_brouillon)




