
#########################################################################################################
#######Calcul des indices
#########################################################################################################

i_debut=25 #janvier 2013

##########
##### I) Indice de la note : v représente ce que l'on va multiplier par décembre à chaque fois
g<-glissements_3
l=length(g[1,])
v<-g[,i_debut:l]
for (i in c(1:11)){
  v<-v*g[,(i_debut-i):(l-i)]
}
v<-v^(1/12)
#On construit l'indice
indice_3_note<-indice_publie_9812
indice_3_note[181:240]<-0
names(indice_3_note)[181:240]<-names(glissements_3[1,25:84])
for (j in c(181:240)){
  dernier_decembre<-12*(j%/%12)*(j%%12>0)+12*((j-1)%/%12)*(j%%12==0)
  dernier_decembre
  indice_3_note[j]<-indice_3_note[dernier_decembre]*prod(v[,j-180]^poids_3[,j-180])
}
indice_3_note

plot(c(1:240),indice_3_note,xlab="Mois",ylab="Indice",xaxt='n')
abline(v=180)

#Variante : en faisant commencer l'indice début 2014 et non début 2013 :
indice_3_note_bis<-indice_publie_9813
indice_3_note_bis[193:240]<-0
names(indice_3_note_bis)[193:240]<-names(glissements_3[1,37:84])
for (j in c(193:240)){
  dernier_decembre<-12*(j%/%12)*(j%%12>0)+12*((j-1)%/%12)*(j%%12==0)
  dernier_decembre
  indice_3_note_bis[j]<-indice_3_note_bis[dernier_decembre]*prod(v[,j-180]^poids_3[,j-180])
}
indice_3_note

plot(c(1:240),indice_3_note_bis,xlab="Mois",ylab="Indice",xaxt='n',type="l")
lines(c(1:238),indice_publie,col="red")
abline(v=192)


##########
# II) Indice actuel
##### Indice actuel
g<-glissements_3
l=length(g[1,])
v<-g[,i_debut:l]
v<-v^(1/12)
#On construit l'indice
indice_3_actuel<-indice_publie_9812
indice_3_actuel[181:240]<-0
names(indice_3_actuel)[181:240]<-names(glissements_3[1,25:84])
for (j in c(181:240)){
  dernier_decembre<-12*(j%/%12)*(j%%12>0)+12*((j-1)%/%12)*(j%%12==0)
  indice_3_actuel[j]<-indice_3_actuel[dernier_decembre]*prod(v[,j-180]^poids_3[,j-180])
}
indice_3_actuel
plot(c(1:238),indice_3_actuel[1:238],xlab="Mois",ylab="Indice",xaxt='n')
plot(c(1:238),indice_3_actuel[1:238],xlab="Mois",ylab="Indice",xaxt='n',type="l")
lines(c(1:238),indice_publie,col="red")
abline(v=180)


##########
#III) Indice "cumulé" (comme l'indice actuel mais en cumulant les glissements annuels puissance 1/12)
g<-glissements_3
l=length(g[1,])
v<-g[,i_debut:l]
v<-v^(1/12)
#On construit l'indice
indice_3_cumul<-indice_publie_9812
indice_3_cumul[181:240]<-0
names(indice_3_cumul)[181:240]<-names(glissements_3[1,25:84])
for (j in c(181:240)){
  indice_3_cumul[j]<-indice_3_cumul[j-1]*prod(v[,j-180]^poids_3[,j-180])
}
indice_3_cumul
plot(c(1:240),indice_3_cumul,xlab="Mois",ylab="Indice",xaxt='n')
plot(c(1:240),indice_3_cumul,xlab="Mois",ylab="Indice",xaxt='n',type="l")
abline(v=180)
lines(c(1:238),indice_publie,col="red")


##########
#IV) Indice Marc1 (mois séparés)
g<-glissements_3
l=length(g[1,])
v<-g[,i_debut:l]
#On construit l'indice
indice_3_marcun<-indice_publie_9812
indice_3_marcun[181:240]<-0
names(indice_3_marcun)[181:240]<-names(glissements_3[1,25:84])
for (j in c(181:240)){
  indice_3_marcun[j]<-indice_3_marcun[j-12]*prod(v[,j-180]^poids_3[,j-180])
}
indice_3_marcun

plot(c(1:240),indice_3_marcun,xlab="Mois",ylab="Indice",xaxt='n')
abline(v=180)
plot(c(1:240),indice_3_marcun,xlab="Mois",ylab="Indice",xaxt='n',type="l")
lines(c(1:238),indice_publie,col="red")
abline(v=180)


##########
#V) Indice Marc2 (comme la note mais appliqué à l'indice un an avant, ie au même mois mais pour l'année n-1)
g<-glissements_3
l=length(g[1,])
v<-glissements_3[,i_debut:l]
for (i in c(1:11)){
  v<-v*g[,(i_debut-i):(l-i)]
}
v<-v^(1/12)
#On construit l'indice
indice_3_marcdeux<-indice_publie_9812
indice_3_marcdeux[181:240]<-0
names(indice_3_marcdeux)[181:240]<-names(glissements_3[1,25:84])
for (j in c(181:240)){
  dernier_decembre<-12*(j%/%12)*(j%%12>0)+12*((j-1)%/%12)*(j%%12==0)
  dernier_decembre
  indice_3_marcdeux[j]<-indice_3_marcdeux[j-12]*prod(v[,j-180]^poids_3[,j-180])
}
indice_3_marcdeux

plot(c(1:240),indice_3_marcdeux,xlab="Mois",ylab="Indice",xaxt='n')
abline(v=180)
plot(c(1:240),indice_3_marcdeux,xlab="Mois",ylab="Indice",xaxt='n',type="l")
abline(v=180)
lines(c(1:238),indice_publie,col="red")

#Variante : en faisant commencer l'indice début 2014 et non début 2013 :
indice_3_marcdeux_bis<-indice_publie_9813
indice_3_marcdeux_bis[193:240]<-0
names(indice_3_marcdeux_bis)[193:240]<-names(glissements_3[1,37:84])
for (j in c(193:240)){
  dernier_decembre<-12*(j%/%12)*(j%%12>0)+12*((j-1)%/%12)*(j%%12==0)
  dernier_decembre
  indice_3_marcdeux_bis[j]<-indice_3_marcdeux_bis[j-12]*prod(v[,j-180]^poids_3[,j-180])
}
indice_3_marcdeux

plot(c(1:240),indice_3_marcdeux_bis,xlab="Mois",ylab="Indice",xaxt='n',type="l")
lines(c(1:238),indice_publie,col="red")
abline(v=192)


#VI) Utiliser l'indice cumulé pendant un an puis l'indice mois séparés :
g<-glissements_3
l=length(g[1,])
v<-glissements_3[,i_debut:l]
#On construit l'indice
indice_3_hybride1<-indice_publie_9812
indice_3_hybride1[181:240]<-0
names(indice_3_hybride1)[181:240]<-names(glissements_3[1,25:84])
for (j in c(181:192)){
  indice_3_hybride1[j]<-indice_3_hybride1[j-1]*prod(v[,j-180]^(poids_3[,j-180]/12))
}
for (j in c(193:240)){
  dernier_decembre<-12*(j%/%12)*(j%%12>0)+12*((j-1)%/%12)*(j%%12==0)
  indice_3_hybride1[j]<-indice_3_hybride1[j-12]*prod(v[,j-180]^(poids_3[,j-180]))
}
indice_3_hybride1

plot(c(1:240),indice_3_hybride1,xlab="Mois",ylab="Indice",xaxt='n')
abline(v=180)
plot(c(1:240),indice_3_hybride1,xlab="Mois",ylab="Indice",xaxt='n',type="l")
abline(v=180)
lines(c(1:238),indice_publie,col="red")


#VII) Utiliser l'indice cumulé pendant un an puis l'indice Marc2
g<-glissements_3
l=length(g[1,])
v<-glissements_3[,i_debut:l]
#On construit l'indice
indice_3_hybride2<-indice_publie_9812
indice_3_hybride2[181:240]<-0
names(indice_3_hybride2)[181:240]<-names(glissements_3[1,25:84])
#○D'abord le cumulé
for (j in c(181:192)){
  indice_3_hybride2[j]<-indice_3_hybride2[j-1]*prod(v[,j-180]^(poids_3[,j-180]/12))
}
#Puis le marc2
for (i in c(1:11)){
  v<-v*g[,(i_debut-i):(l-i)]
}
for (j in c(193:240)){
  dernier_decembre<-12*(j%/%12)*(j%%12>0)+12*((j-1)%/%12)*(j%%12==0)
  indice_3_hybride2[j]<-indice_3_hybride2[j-12]*prod(v[,j-180]^(poids_3[,j-180]/12))
}
indice_3_hybride2

plot(c(1:240),indice_3_hybride2,xlab="Mois",ylab="Indice",xaxt='n')
abline(v=180)
plot(c(1:240),indice_3_hybride2,xlab="Mois",ylab="Indice",xaxt='n',type="l")
abline(v=180)
lines(c(1:238),indice_publie,col="red")



#VIII) Utiliser l'indice cumulé pendant deux ans puis l'indice mois séparés :
g<-glissements_3
l=length(g[1,])
v<-glissements_3[,i_debut:l]
#On construit l'indice
indice_3_hybride3<-indice_publie_9812
indice_3_hybride3[181:240]<-0
names(indice_3_hybride3)[181:240]<-names(glissements_3[1,25:84])
for (j in c(181:204)){
  indice_3_hybride3[j]<-indice_3_hybride3[j-1]*prod(v[,j-180]^(poids_3[,j-180]/12))
}
for (j in c(205:240)){
  dernier_decembre<-12*(j%/%12)*(j%%12>0)+12*((j-1)%/%12)*(j%%12==0)
  indice_3_hybride3[j]<-indice_3_hybride3[j-12]*prod(v[,j-180]^(poids_3[,j-180]))
}
indice_3_hybride3

plot(c(1:240),indice_3_hybride3,xlab="Mois",ylab="Indice",xaxt='n')
abline(v=180)
plot(c(1:240),indice_3_hybride3,xlab="Mois",ylab="Indice",xaxt='n',type="l")
abline(v=180)
lines(c(1:238),indice_publie,col="red")


#IX) Utiliser l'indice publié, puis les deux dernières années l'indice cumulé
g<-glissements_3
l=length(g[1,])
v<-glissements_3[,i_debut:l]
#On construit l'indice
indice_3_cumulrec<-indice_publie_9812
indice_3_cumulrec[181:240]<-0
names(indice_3_cumulrec)[181:240]<-names(glissements_3[1,25:84])
for (j in c(181:216)){
  indice_3_cumulrec[j]<-indice_publie[j]
}
for (j in c(217:240)){
  indice_3_cumulrec[j]<-indice_3_cumulrec[j-1]*prod(v[,j-180]^(poids_3[,j-180]/12))
}
indice_3_cumulrec

plot(c(1:240),indice_3_cumulrec,xlab="Mois",ylab="Indice",xaxt='n')
abline(v=180)
plot(c(1:240),indice_3_cumulrec,xlab="Mois",ylab="Indice",xaxt='n',type="l")
abline(v=180)
lines(c(1:240),indice_3_actuel,col="red")

