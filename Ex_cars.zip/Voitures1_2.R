#Import des librairies
library(xlsx)

lignes_1an<-c(7:14,16:23,25:34,36:38,40:42,44:48,50:53)

for (year in c(2011:2015)){
  fichier<-read.xlsx(paste("Occasion ",year,"_Indice.xls",sep=""),colClasses = c("character",rep("integer",24),"character",rep("integer",18)),sheetName="1an",header=F)
  
}
