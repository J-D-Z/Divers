#Import des librairies
library(xlsx)



#Projet voitures d'occasion

historique<-read.csv2("historique.csv",sep=",")
correspondances1=read.csv2("Correspondances1.csv",sep=";")


View(historique)
View(correspondances1)


#Pour l'instant travaillons sur les voitures d'ancienneté 1 an
historique1=historique[which(historique$ANCIENNETE==1 & historique$ANNEE>2012),]
View(correspondances1)

#On crée une colonne indice

l1=length(correspondances1[,1])
correspondances1[,"code"]<-c(1:l1)

indices1<-data.frame(c(1:l1))
indices1[,2]<-100
names(indices1)<-c("code","1-2013")

for (year=2013:2017){
  for (mois=1:12){
      if ()
  }
  
}
  
    